# VITAL Rule Engine — Pseudocode

Version 1.0. Rein regelbasiert, deterministisch, lokal. **Keine Diagnose, keine Dosierung, keine Produktempfehlung.**

## 1. Datenfluss

```
user inputs ─┐
labs ────────┼─► normalize ─► evaluate rules ─► aggregate per focus-area ─► UI labels
symptoms ────┘                     │
                                   └─► red-flag detector ─► consult / emergency banner
```

## 2. Zentrale Regel-Typen

| Typ | Quelle | Output |
|---|---|---|
| `LifestyleRule` | `lifestyle-rules.json` | Fokusbereich-Score + Textbaustein |
| `LabBand` | `lab-markers.json` | Band-Label je Messwert |
| `SymptomMap` | `symptom-map.json` | Fokusbereich-Score + optional Red Flag |
| `RedFlagBundle` | `symptom-map.json` | Konsultations- oder Notfallhinweis |
| `SupplementFact` | `supplement-safety.json` | Rein informativ, kein Score |

## 3. Pseudocode

```pseudo
function evaluate(user, entries, labs, symptoms, config) {
  const now = clock.now()
  const scoreByArea = map()      // focusAreaId → { score, evidence[] }
  const flags = []

  // --- 3a. Lifestyle-Regeln ---
  for rule in load("lifestyle-rules.json").rules:
    if matchesCondition(rule, entries, now):
      for areaId in rule.focusAreas:
        scoreByArea[areaId].score += severityWeight(rule.severity)
        scoreByArea[areaId].evidence.push({
          type: "lifestyle",
          ruleId: rule.id,
          message: rule.message,
          severity: rule.severity,
          sources: rule.sources
        })
      if rule.severity == "urgent":
        flags.push({ level: "emergency", message: rule.message, sources: rule.sources })
      else if rule.severity == "strong":
        flags.push({ level: "consult", message: rule.message, sources: rule.sources })

  // --- 3b. Laborwerte ---
  for lab in labs:
    marker = lookup("lab-markers.json", lab.id)
    band = pickBand(marker, lab.value, user.sexAgeGroup)
    if band.severity in ["medium","high"]:
      focusId = marker.category          // z.B. "eisen", "vitamin_d"
      scoreByArea[focusId].score += bandWeight(band.severity)
      scoreByArea[focusId].evidence.push({
        type: "lab",
        markerId: marker.id,
        value: lab.value,
        unit: marker.unit,
        label: band.label,
        sources: marker.sources
      })
      if band.severity == "high":
        flags.push({
          level: "consult",
          message: `${marker.label}: ${band.label}`,
          sources: marker.sources
        })

  // --- 3c. Symptome ---
  for s in symptoms:
    def = lookup("symptom-map.json", s.id)
    for areaId in def.mapsTo:
      scoreByArea[areaId].score += def.weight
      scoreByArea[areaId].evidence.push({
        type: "symptom",
        symptomId: def.id,
        label: def.label,
        sources: def.sources
      })
    // akuter Notfall
    if s matches any(def.acuteEmergency):
      flags.push({ level: "emergency", message: def.acuteText ?? disclaimer.emergency })

  // --- 3d. Red-Flag-Bundles ---
  for bundle in load("symptom-map.json").redFlagBundles:
    if symptomsSatisfy(bundle.match, symptoms, now):
      flags.push({
        level: bundle.output,             // "consult" oder "emergency"
        message: bundle.message,
        sources: bundle.sources
      })

  // --- 3e. Aggregation ---
  ranked = sortByDescending(scoreByArea, entry.score)
  top = first(ranked, config.maxFocusAreas ?? 3)

  return {
    focusAreas: top.map(a => ({
      id: a.id,
      label: focusAreas[a.id].label,
      evidence: a.evidence,
      framingText: pickFraming(a.score, disclaimer.ctaPhrasing)
    })),
    flags: dedupe(flags),
    disclaimer: disclaimer.global.primary
  }
}
```

## 4. Helper-Funktionen

```pseudo
function matchesCondition(rule, entries, now):
  // unterstützte Operatoren: lt, lte, gt, gte, eq
  //                         daysOutOfLast + minCount
  //                         sumOverDays, percentChangeOverDays
  //                         perDay, perIntake, durationDays
  // Implementierung: reines Zählen über entries — keine ML, keine Heuristik.

function severityWeight(sev):
  return { info: 0, soft: 1, medium: 2, strong: 3, urgent: 4 }[sev]

function bandWeight(sev):
  return { ok: 0, low: 1, medium: 2, high: 3 }[sev]

function pickFraming(score, phrasing):
  if score >= 3 → phrasing.strongSuggestion.sample()
  elif score >= 2 → phrasing.mediumSuggestion.sample()
  else → phrasing.softSuggestion.sample()

function pickBand(marker, value, group):
  bands = marker.bandsByGroup?.[group] ?? marker.bands
  return first(bands, b => (b.min ?? -Inf) ≤ value < (b.max ?? +Inf))
```

## 5. Output-Kontrakt an die UI

```ts
type EvaluationResult = {
  focusAreas: Array<{
    id: FocusAreaId            // "energie" | "schlaf" | ...
    label: string
    evidence: Evidence[]
    framingText: string        // aus disclaimer-copy.json
  }>
  flags: Array<{
    level: "consult" | "emergency"
    message: string
    sources: SourceId[]
  }>
  disclaimer: string           // immer anzeigen
}
```

Die UI darf nur mit diesem Objekt arbeiten. Rohdaten (Scores, Schwellen) werden nicht gezeigt.

## 6. Verbotene Operationen (hard-coded)

Die Engine darf niemals:

1. Produkt- oder Markennamen ausgeben.
2. Dosierungszahlen an einzelne Nutzer ausgeben (nur allgemeine DGE-/BfR-Werte im Wissen-Bereich).
3. Formulierungen nutzen, die in `disclaimer-copy.json.framingVerbs.neverUse` aufgeführt sind.
4. Diagnosebegriffe wie „hat Diabetes“, „leidet an Burnout“ erzeugen.

Diese Liste wird vor dem Rendern geprüft (Wortfilter) und die Ausgabe bei Treffer auf den sicheren Default zurückgesetzt:
> „Mögliche Fokusbereiche wurden erkannt. Bitte im Blick behalten und bei Bedarf ärztlich abklären lassen.“

## 7. Teststrategie

- Snapshot-Tests pro JSON-Regel → gleicher Input ⇒ gleicher Text.
- Red-Flag-Suite: synthetische Fälle (Brustschmerz, suizidale Gedanken, 180/120 mmHg) müssen jeweils einen `emergency`-Flag erzeugen.
- Verbotene-Wörter-Filter auf jede erzeugte UI-Zeichenkette.

## 8. Versionierung

Jede JSON-Datei trägt ein `version`-Feld. Die Engine lehnt das Rendering ab, wenn die Versionen unter den Dateien inkompatibel sind (Major-Version ≠).
