# VITAL — lokale Wissens- und Regelbasis

Stand 1.0.0 · zuletzt geprüft 2025-11 · **Keine Diagnose. Keine Dosierung. Kein Medizinprodukt.**

Diese Sammlung ist die Datenbasis für die lokale PWA VITAL. Sie wird **ausschließlich** zur Orientierung genutzt — die App trifft keine medizinischen Entscheidungen und empfiehlt keine Produkte.

## Dateien

| Datei | Inhalt |
|---|---|
| `source-library.json` | Zentrale Quellen (DGE, BfR, RKI, NICE, AWMF) — jede Regel referenziert hier per `sourceId`. |
| `focus-areas.json` | Die 9 Fokusbereiche (Energie, Schlaf, Stress, Flüssigkeit, Regeneration, Eisen, Vitamin D, Vitamin B12, Magnesium). |
| `lab-markers.json` | Orientierungsbereiche für Laborwerte aus Leitlinien. Keine Referenzbereiche einzelner Labore. |
| `symptom-map.json` | Mapping Symptom → mögliche Fokusbereiche + Red-Flag-Bundles. |
| `lifestyle-rules.json` | Alltagsregeln für Schlaf, Wasser, Koffein, Training, Puls, Blutdruck, Stress, Gewicht, Kreatin. |
| `supplement-safety.json` | DGE-Referenzwerte + BfR-Höchstmengen-Vorschläge + Warnhinweise. **Keine Dosierungsempfehlungen.** |
| `disclaimer-copy.json` | Zentral versionierte Textbausteine (Haftungshinweise, Framing-Verben, CTA-Phrasing). |
| `rule-engine-pseudocode.md` | Pseudocode-Spezifikation der Regel-Engine. |

## Quellenpriorität

1. **DGE Referenzwerte** — Zufuhrempfehlungen
2. **BfR Höchstmengenvorschläge** — Sicherheitsobergrenzen in NEM
3. **RKI Gesundheitsinformationen** — Epidemiologie, allgemeine Public-Health-Aussagen
4. **NICE Guidelines** — diagnostisches Framing, Schwellenwerte
5. **Leitlinien / Reviews** — AWMF, ESC, DGSM, WHO — als Kontext

Einzelne schwache Studien werden **nicht** als Hauptbasis genutzt.

## Prinzipien der Formulierung

- „möglicher Fokusbereich"
- „im Blick behalten"
- „ärztlich abklären lassen"
- niemals „du hast {X}"
- niemals Dosierungsempfehlungen an Einzelne
- niemals Produktkäufe empfehlen

Die verbotenen Formulierungen stehen in `disclaimer-copy.json.framingVerbs.neverUse`. Die Engine prüft vor dem Rendern gegen diese Liste.

## Update-Prozess

1. Quelle prüfen (URL lebt, Datum aktuell).
2. Felder aktualisieren, `lastReviewed` hochziehen.
3. Bei Schema-Änderungen `version` der betroffenen Datei erhöhen.
4. Regel-Engine-Snapshot-Tests laufen lassen.
5. Release-Note dokumentieren, welche Quelle sich geändert hat.

## Nicht-Ziele

- Kein Tracking, kein Scoring im Sinne eines „Gesundheitsindex".
- Keine Empfehlung einzelner Nährstoffmengen oder Produkte.
- Keine Interpretation individueller Laborbefunde — Labor ist immer maßgeblich.
- Keine Notfallversorgung — bei akuten Beschwerden 112.
